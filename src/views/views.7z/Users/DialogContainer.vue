<template>
  <k-dialog @close="cancel">
    <div :style="{ marginBottom: '1rem' }">
      <label>
        Product Name<br />
        <k-input
          type="text"
          :name="'UserName'"
          v-model="userInEdit.userName"
        ></k-input>
      </label>
    </div>
    <div :style="{ marginBottom: '1rem' }">
      <label>
        Email<br />
        <k-input :name="'email'" v-model="userInEdit.email"></k-input>
      </label>
    </div>
    <div>
      <label>
        Phone Number <br />
        <k-input
          type="text"
          :name="'Phone Number'"
          v-model="userInEdit.phoneNumber"
        ></k-input
      ></label>
    </div>
    MultiSelect value: {{ multiselectValue }}

    <kendo-multiselect
      v-model="multiselectValue"
      :data-source="dataSourceArray"
      :data-text-field="'text'"
      :data-value-field="'value'"
      :placeholder="'Select size...'"
      :filter="'contains'"
    >
    </kendo-multiselect>
    <dialog-actions-bar>
      <button class="k-button" @click="cancel">Cancel</button>
      <button class="k-button k-primary" @click="save">Save</button>
    </dialog-actions-bar>
  </k-dialog>
</template>
<script>
import { Dialog, DialogActionsBar } from "@progress/kendo-vue-dialogs";
import { NumericTextBox, Input } from "@progress/kendo-vue-inputs";
import { MultiSelect } from "@progress/kendo-dropdowns-vue-wrapper";

export default {
  components: {
    "k-input": Input,
    numerictextbox: NumericTextBox,
    "k-dialog": Dialog,
    "dialog-actions-bar": DialogActionsBar,
    "kendo-multiselect": MultiSelect,
  },
  props: {
    dataItem: Object,
  },
  data: function () {
    return {
      userInEdit: {
        UserName: "",
        email: 0,
        phoneNumber: false,
      },
      multiselectValue: [{ text: "Baseball", value: "1" }],
      dataSourceArray: [
        { text: "Baseball", value: "1" },
        { text: "Basketball", value: "2" },
        { text: "Cricket", value: "3" },
        { text: "Football", value: "4" },
        { text: "Tennis", value: "5" },
        { text: "Volleyball", value: "6" },
      ],
    };
  },
  created: function () {
    if (this.$props.dataItem) {
      this.userInEdit = this.$props.dataItem;
    }
  },
  methods: {
    cancel() {
      this.$emit("cancel");
    },
    save() {
      this.$emit("save");
    },
  },
};
</script>