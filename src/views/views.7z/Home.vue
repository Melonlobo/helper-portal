<template>
  <div class="p-5">
    <Home msg="Novigo Solutions" />
  </div>
</template>

<script>
// @ is an alias to /src
import Home from "@/components/Home.vue";

export default {
  name: "home",
  components: {
    Home,
  },
};
</script>
<style scoped>
</style>