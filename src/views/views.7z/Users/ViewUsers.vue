<template>
  <div class="example-wrapper">
    <Grid
      ref="grid"
      :style="{ height: '440px' }"
      :data-items="users"
      :columns="columns"
    >
      <template v-slot:myTemplate="{ props }">
        <custom :data-item="props.dataItem" @edit="edit" @remove="remove" />
      </template>
      <grid-toolbar class="text-left">
        <button title="Add new" class="m-2 k-button k-primary" @click="insert">
          Add new
        </button>
      </grid-toolbar>
      <grid-norecords> There is no data available custom </grid-norecords>
    </Grid>
    <dialog-container
      v-if="userInEdit"
      :data-item="userInEdit"
      @save="save"
      @cancel="cancel"
    >
    </dialog-container>
  </div>
</template>
<script>
import { Grid, GridToolbar, GridNoRecords } from "@progress/kendo-vue-grid";
import { sampleUsers } from "./data";
import DialogContainer from "./DialogContainer";
import CommandCell from "./CommandCell";

export default {
  components: {
    Grid: Grid,
    "grid-toolbar": GridToolbar,
    "grid-norecords": GridNoRecords,
    "dialog-container": DialogContainer,
    custom: CommandCell,
  },
  data: function () {
    return {
      sort: [{ field: "UserID", dir: "asc" }],
      users: sampleUsers,
      userInEdit: undefined,
      columns: [
        { field: "UserID", editable: false, title: "ID", width: "40px" },
        {
          field: "userName",
          title: "User Name",
          width: "100px",
        },
        { field: "email", title: "Email", width: "100px" },

        { field: "phoneNumber", title: "Phone Number" },

        { field: "Roles", title: "Roles" },
        { cell: "myTemplate", width: "100px" },
      ],
    };
  },
  methods: {
    edit(dataItem) {
      this.userInEdit = this.cloneProduct(dataItem);
    },
    remove(dataItem) {
      this.users = this.users.filter((p) => p.UserID !== dataItem.UserID);
    },
    save() {
      const dataItem = this.userInEdit;
      const users = this.users.slice();
      const isNewUser = dataItem.UserID === undefined;

      if (isNewUser) {
        users.unshift(this.newUser(dataItem));
      } else {
        const index = users.findIndex((p) => p.UserID === dataItem.UserID);
        users.splice(index, 1, dataItem);
      }

      this.users = users;
      this.userInEdit = undefined;
    },
    cancel() {
      this.userInEdit = undefined;
    },
    insert() {
      this.userInEdit = {};
    },
    dialogTitle() {
      return `${this.userInEdit.UserID === undefined ? "Add" : "Edit"} product`;
    },
    cloneProduct(product) {
      return Object.assign({}, product);
    },
    newUser(source) {
      const id =
        this.users.reduce(
          (acc, current) => Math.max(acc, current.UserID || 0),
          0
        ) + 1;
      const newUser = {
        UserID: id,
        userName: "",
        email: "",
        phoneNumber: "",
        Roles: [],
      };

      return Object.assign(newUser, source);
    },
  },
};
</script>