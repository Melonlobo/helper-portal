<template src="./UserForm.html"></template>

<script>
import { required } from "vuelidate/lib/validators";
import axios from "axios";
export default {
  data: function () {
    return {
      userData: {
        username: "",
        email: "",
        phoneNumber: "",
        password: "",
      },
      showMsg: false,
    };
  },
  validations: {
    userData: {
      password: {
        required,
        strongPassword(password) {
          return (
            /[A-Z]/.test(password) &&
            /[a-z]/.test(password) && // checks for a-z
            /[0-9]/.test(password) && // checks for 0-9
            /\W|_/.test(password) && // checks for special char
            password.length >= 6
          );
        },
      },
    },
  },
  methods: {
    changed: function (event) {
      console.log(event);
    },
    addUser: async function () {
      this.$v.$touch();
      console.log(this.$v.$touch());
      if (!this.$v.$invalid) {
        let data = {
          Username: this.userData.username,
          Email: this.userData.email,
          PhoneNumber: this.userData.phoneNumber,
          PasswordHash: this.userData.password,
        };
        try {
          //const response = await axios.post("https://localhost:5001/api/User/AddUser", data);
          const response = await axios.post(
            "https://novigoidentityapi.azurewebsites.net/api/User/AddUser",
            data
          );
          this.status = response.data.status;
          this.responseMsg = response.data.message;
          this.showMsg = true;
          this.userData = {};
          //this.$router.push("/home");
        } catch (err) {
          console.log("Ooops!" + err);
        }
      }
    },
  },
};
</script>
<style scoped>
.title {
  font-weight: 600;
  margin-bottom: 30px;
  margin-top: 5px;
  padding: 10px;
  padding-left: 50px;
  border: 1px solid rgb(235, 230, 230);
}

.form-check {
  display: flex;
  padding-left: 20px;
}
.col-sm-9 {
  padding-right: 30px;
  padding-left: 30px;
}
</style>