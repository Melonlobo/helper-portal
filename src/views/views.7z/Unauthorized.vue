<template>
  <div>
    <p>You do not have permissions or your sign in failed</p>
  </div>
</template>