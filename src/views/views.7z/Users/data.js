
export const sampleUsers = [
    {
        "UserID":1,
        "userName":"Sunil@novigosolutions.com",
        "email":"Sunil@novigosolutions.com",
        "phoneNumber":"8861244000",
        "PasswordHash" : "Novigo@123",
        "Roles":['Admin','Finance','HR']
    },{
        "UserID":2,
        "userName":"saiful",
        "email":"sa@mail.com",
        "phoneNumber":"9895648989",
        "PasswordHash" : "Novigo@123",
        "Roles":['Admin','Finance']
    },{
        "UserID":3,
        "userName":"manjunath",
        "email":"manjunath@mail.com",
        "phoneNumber":"1234567890",
        "PasswordHash" : "Novigo@123",
        "Roles":['Finance','HR']
    },{
        "UserID":4,
        "userName":"allan",
        "email":"allan@mail.com",
        "phoneNumber":"1234123412",
        "PasswordHash" : "Pass@123",
        "Roles":['HR']
    },
   
];
