<template src="./TenantForm.html"></template>

<script>
import axios from "axios";
export default {
  data: function () {
    return {
      tenantData: {},
      identityPools: this.getIdentityPools(),
      showMsg: false,
    };
  },
  methods: {
    changed: function (event) {
      console.log(event);
    },
    addTenant: async function () {
      let data = {
        Name: this.tenantData.tenantName,
        IdentityPoolID: this.tenantData.identityPool.id,
      };
      try {
        //const response = await axios.post("https://localhost:5001/api/Tenant/AddTenant", data);
        const response = await axios.post(
          "https://novigoidentityapi.azurewebsites.net/api/Tenant/AddTenant",
          data
        );
        this.status = response.data.status;
        this.responseMsg = response.data.message;
        this.showMsg = true;
        this.tenantData = {};
        //this.$router.push("/home");
      } catch (err) {
        this.values.push("Ooops!" + err);
      }
    },
    getIdentityPools: async function () {
      //const response = await axios.get("https://localhost:5001/api/IdentityPool/GetIdentityPools");
      const response = await axios.get(
        "https://novigoidentityapi.azurewebsites.net/api/IdentityPool/GetIdentityPools"
      );
      this.identityPools = response.data.result;
      console.log("Identity Pools : ", this.identityPools);
    },
  },
  mounted() {
    this.displayIdentityPools();
  },
};
</script>
<style scoped>
.title {
  font-weight: 600;
  margin-bottom: 30px;
  margin-top: 5px;
  padding: 10px;
  padding-left: 50px;
  border: 1px solid rgb(235, 230, 230);
}

.form-check {
  display: flex;
  padding-left: 20px;
}

.col-sm-9 {
  padding-right: 30px;
  padding-left: 30px;
}
</style>